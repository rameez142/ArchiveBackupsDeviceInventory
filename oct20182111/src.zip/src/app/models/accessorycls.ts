export class accessorycls
{
  deviceid:number ;
  devicenumber:string;
  ahwalid:number ;
  model: string;

  devicetypeid:number ;
  defective: number ;

  rental:number ;
  barcode: string;
}



