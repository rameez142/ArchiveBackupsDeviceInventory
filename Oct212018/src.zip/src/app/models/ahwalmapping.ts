export class ahwalmapping {
    ahwalID?:number;
    sectorID?:number;
    cityGroupID?:number;
    shiftID?:number ;
    patrolRoleID?:number;
    personID?:number;
    ahwalMappingID?:number;
    milNumber?:number;
    rankID?:number;
    personName?:string;
    callerID?:string;
    hasDevices?:number;
    serial?:string;
    plateNumber?:string;
    patrolPersonStateID?:number;
    sortingIndex?:number;
}
