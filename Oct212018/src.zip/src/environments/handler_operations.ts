export const handler_operations = {
         Opeartion_AddPerson : 6,
         Opeartion_UpdatePerson : 7,
         Opeartion_DeletePerson : 8,
         Opeartion_AddPatrolCar : 9,
         Opeartion_UpdatePatrolCar : 10,
         Opeartion_DeletePatrolCar : 11,
         Opeartion_AddHandHeld : 12,
         Opeartion_UpdateHandHeld : 13,
         Opeartion_DeleteHandHeld : 14,
         Opeartion_UserLogin : 15,
         Opeartion_UserLogOut : 16,
         Opeartion_UserUpdatePassword : 17,

         Opeartion_Mapping_AddNew : 18,
         Opeartion_Mapping_Remove : 19,
         Opeartion_Mapping_Update : 20,
         Opeartion_Mapping_CheckInPatrolAndHandHeld : 21,
         Opeartion_Mapping_CheckOutPatrolAndHandHeld : 22,
         Opeartion_Mapping_AhwalMappingGetAllData : 23,
         Opeartion_Mapping_Ahwal_ChangePersonState : 24,

         Opeartion_Mapping_Ops_ChangePersonState : 25,

         Opeartion_Incidents_AddNew : 26,
         Opeartion_Incidents_Modify : 27,
         Opeartion_Incidents_Delete : 28,
         Opeartion_Incidents_Close : 29,

         Opeartion_Incidents_NewComment: 30,

         Opeartion_Incidents_HandOverIncident : 31,
         Opeartion_Incidents_UnHandOverIncident : 32,

         Opeartion_IncidentsTypes_AddNew : 33,
         Opeartion_IncidentsTypes_Edit : 34,

 Opeartion_Status_Success:1 ,
Opeartion_Status_Failed:2 ,
 Opeartion_Status_UnAuthorized: 3 ,
 Opeartion_Status_UnKnownError : 4 ,
 Opeartion_Status_LoginSuccess : 5 ,
 Opeartion_Status_LoginFail : 6
};
