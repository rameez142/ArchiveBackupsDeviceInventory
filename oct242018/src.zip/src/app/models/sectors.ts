export class sectors {
    sectorID:number;
    ahwalID:number;
    shortName:string;
    callerPrefix:string;
    disabled:number;
}