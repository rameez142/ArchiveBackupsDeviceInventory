export const handler_incident = {
      Incident_State_New:10,
    Incident_State_HasComments:20,
    Incident_State_Closed:30
};